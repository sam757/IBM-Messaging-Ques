package com.example.demo_ibm_mq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoIbmMqApplicationTests {

	@Test
	void contextLoads() {
	}

}
