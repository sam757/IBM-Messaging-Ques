package com.example.demo_ibm_mq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.owasp.security.logging.util.SecurityUtil;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MQListener {
	@JmsListener(containerFactory = "qm1JmsListenerContainerFactory", destination = "${project.mq.queue-name}")
	public void receiveMessageQM1(final Message jsonMessage) throws JMSException{
		String messageData = null;
		if(jsonMessage instanceof TextMessage) {
			TextMessage textMessage = (TextMessage)jsonMessage;
			messageData = textMessage.getText();
			SecurityUtil.logMessage("Received QM1111:" + messageData);
		}
	}

	@JmsListener(containerFactory = "qm2JmsListenerContainerFactory", destination = "${project.mq2.queue-name}")
	public void receiveMessageQM2(final Message jsonMessage) throws JMSException{
		String messageData = null;
		if(jsonMessage instanceof TextMessage) {
			TextMessage textMessage = (TextMessage)jsonMessage;
			messageData = textMessage.getText();
			SecurityUtil.logMessage("Received QM2222:" + messageData);
		}
	}
}
