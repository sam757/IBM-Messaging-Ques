package com.example.demo_ibm_mq;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;

import javax.net.ssl.SSLSocketFactory;

@Configuration
public class MQConfiguration {
    @Value("${project.mq.port}")
    private Integer port;
    @Value("${project.mq.queue-manager}")
    private String queueManager;
    @Value("${project.mq.channel}")
    private String channel;

    @Autowired
    private MQService mqService;

    @Bean("qm1SslSocketFactory")
    public SSLSocketFactory sslSocketFactory() throws Exception {
        return mqService.genSslSocketFactory();
    }

    @Bean("qm1MqQueueConnectionFactory")
    public MQQueueConnectionFactory mqQueueConnectionFactory(@Qualifier("qm1SslSocketFactory") SSLSocketFactory sslSocketFactory) {
        return mqService.genMqQueueConnectionFactory(sslSocketFactory, port, channel, queueManager);
    }

    @Bean("qm1UserCredentialsConnectionFactoryAdapter")
    UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter(@Qualifier("qm1MqQueueConnectionFactory") MQQueueConnectionFactory mqQueueConnectionFactory) {
        return mqService.genUserCredentialsConnectionFactoryAdapter(mqQueueConnectionFactory);
    }

    @Bean("qm1CachingConnectionFactory")
    @Primary
    public CachingConnectionFactory cachingConnectionFactory(@Qualifier("qm1UserCredentialsConnectionFactoryAdapter") UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter) {
        return mqService.genCachingConnectionFactory(userCredentialsConnectionFactoryAdapter);
    }

    @Bean("qm1JmsListenerContainerFactory")
    public JmsListenerContainerFactory<?> jmsListenerContainerFactory(@Qualifier("qm1MqQueueConnectionFactory") MQQueueConnectionFactory mqQueueConnectionFactory, DefaultJmsListenerContainerFactoryConfigurer configurer){
        return mqService.genJmsListenerContainerFactory(mqQueueConnectionFactory, configurer);
    }

    @Bean("qm1JmsOperations")
    public JmsTemplate jmsTemplate(@Qualifier("qm1CachingConnectionFactory") CachingConnectionFactory cachingConnectionFactory) {
        return mqService.genJmsTemplate(cachingConnectionFactory);
    }
}
