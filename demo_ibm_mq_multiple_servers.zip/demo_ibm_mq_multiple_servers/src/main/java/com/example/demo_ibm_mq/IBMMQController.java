package com.example.demo_ibm_mq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsOperations;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IBMMQController {
	
	@Value("${project.mq.queue-name}")
    private String queueName;

	@Value("${project.mq2.queue-name}")
	private String queueName2;
	
	@Autowired
	@Qualifier("qm1JmsOperations")
	private JmsOperations jmsOperations;

	@Autowired
	@Qualifier("qm2JmsOperations")
	private JmsOperations jmsOperations2;

	@GetMapping("/qm1/send")
    public String sendQm1(){
		jmsOperations.convertAndSend(queueName, "Helluuuuuu QM 1111!!!");
        return "Send message QM111 successfully";
    }

	@GetMapping("/qm2/send")
	public String sendQm2(){
		jmsOperations2.convertAndSend(queueName2, "Helluuuuuu world QM2222!!!");
		return "Send message QM2222 successfully";
	}
}
