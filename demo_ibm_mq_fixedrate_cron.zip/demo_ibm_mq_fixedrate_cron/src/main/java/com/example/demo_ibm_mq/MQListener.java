package com.example.demo_ibm_mq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.owasp.security.logging.util.SecurityUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class MQListener {

	@Value("${project.mq.queue-manager}")
	private String queueManager;

	@Value("${project.mq.queue-name}")
	private String queueName;

	@Value("${project.mq2.queue-manager}")
	private String queueManager2;

	@Value("${project.mq2.queue-name}")
	private String queueName2;

	@Autowired
	private MQService mqService;

	@Scheduled(cron = "${project.mq.cron}")
	public void receiveMessageQM1(){
		mqService.listenMessage(queueManager, queueName);
	}

	@Scheduled(fixedRateString = "${project.mq2.fixedRate}")
	public void receiveMessageQM2(){
		mqService.listenMessage(queueManager2, queueName2);
	}
}
