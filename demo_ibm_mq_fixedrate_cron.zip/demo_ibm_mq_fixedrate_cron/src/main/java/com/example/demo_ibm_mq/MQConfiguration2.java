package com.example.demo_ibm_mq;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;

import javax.net.ssl.SSLSocketFactory;

@Configuration
public class MQConfiguration2 {
    @Value("${project.mq2.port}")
    private Integer port;
    @Value("${project.mq2.queue-manager}")
    private String queueManager;
    @Value("${project.mq2.channel}")
    private String channel;

    @Autowired
    private MQService mqService;

    @Bean("qm2SslSocketFactory")
    public SSLSocketFactory sslSocketFactory() throws Exception {
        return mqService.genSslSocketFactory();
    }

    @Bean("qm2MqQueueConnectionFactory")
    public MQQueueConnectionFactory mqQueueConnectionFactory(@Qualifier("qm2SslSocketFactory") SSLSocketFactory sslSocketFactory) {
        return mqService.genMqQueueConnectionFactory(sslSocketFactory, port, channel, queueManager);
    }

    @Bean("qm2UserCredentialsConnectionFactoryAdapter")
    UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter(@Qualifier("qm2MqQueueConnectionFactory") MQQueueConnectionFactory mqQueueConnectionFactory) {
        return mqService.genUserCredentialsConnectionFactoryAdapter(mqQueueConnectionFactory);
    }

    @Bean("qm2CachingConnectionFactory")
    @Primary
    public CachingConnectionFactory cachingConnectionFactory(@Qualifier("qm2UserCredentialsConnectionFactoryAdapter") UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter) {
        return mqService.genCachingConnectionFactory(userCredentialsConnectionFactoryAdapter);
    }

    @Bean("qm2JmsListenerContainerFactory")
    public JmsListenerContainerFactory<?> jmsListenerContainerFactory(@Qualifier("qm2MqQueueConnectionFactory") MQQueueConnectionFactory mqQueueConnectionFactory, DefaultJmsListenerContainerFactoryConfigurer configurer){
        return mqService.genJmsListenerContainerFactory(mqQueueConnectionFactory, configurer);
    }

    @Bean("qm2JmsOperations")
    public JmsTemplate jmsTemplate(@Qualifier("qm2CachingConnectionFactory") CachingConnectionFactory cachingConnectionFactory) {
        return mqService.genJmsTemplate(cachingConnectionFactory);
    }
}
