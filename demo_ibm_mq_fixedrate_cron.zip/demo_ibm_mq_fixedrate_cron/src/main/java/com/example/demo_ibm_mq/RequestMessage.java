package com.example.demo_ibm_mq;

public class RequestMessage {
    private String msgId;
    private String msgBody;

    RequestMessage(String msgId, String msgBody){
        this.msgId = msgId;
        this.msgBody = msgBody;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getMsgBody() {
        return msgBody;
    }

    public void setMsgBody(String msgBody) {
        this.msgBody = msgBody;
    }
}
