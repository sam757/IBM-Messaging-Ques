package com.example.demo_ibm_mq;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import org.owasp.security.logging.util.SecurityUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.BrowserCallback;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import javax.jms.*;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.*;

@Service("mqService")
public class MQService {
    @Value("${project.mq.host}")
    private String host;
    @Value("${project.mq.receive-timeout}")
    private long receiveTimeout;
    @Value("${project.mq.username}")
    private String username;
    @Value("${project.mq.password}")
    private String password;
    @Value("${project.mq.ssl-cipher-suite}")
    private String sslCipherSuite;
    @Value("${project.mq.clientStorePath}")
    private String clientStorePath;
    @Value("${project.mq.clientStorePassword}")
    private String clientStorePassword;

    private Map<String, String> reqLs = new HashMap<>();

    @Autowired
    @Qualifier("qm1JmsOperations")
    private JmsOperations jmsOperations;

    @Autowired
    @Qualifier("qm2JmsOperations")
    private JmsOperations jmsOperations2;

    public SSLSocketFactory genSslSocketFactory() throws Exception {
        String storeType = System.getProperty("javax.net.ssl.keyStoreType", KeyStore.getDefaultType());
        // create manager factory
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        char[] password = null;
        if(clientStorePassword.length() > 0) password = clientStorePassword.toCharArray();
        // create trust store
        KeyStore trustStore = KeyStore.getInstance(storeType);
        trustStore.load(new FileInputStream(clientStorePath), password);
        tmf.init(trustStore);
        // create key store
        KeyStore keyStore = KeyStore.getInstance(storeType);
        keyStore.load(new FileInputStream(clientStorePath), password);
        kmf.init(keyStore, password);
        // init SSL Context
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
        return sslContext.getSocketFactory();
    }

    public MQQueueConnectionFactory genMqQueueConnectionFactory(SSLSocketFactory sslSocketFactory, Integer port, String channel, String queueManager) {
        System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");
//    	System.setProperty("javax.net.ssl.trustStore", clientStorePath);
//    	System.setProperty("javax.net.ssl.trustStorePassword", clientStorePassword);
//    	System.setProperty("javax.net.ssl.keyStore", clientStorePath);
//    	System.setProperty("javax.net.ssl.keyStorePassword", clientStorePassword);

        MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
        mqQueueConnectionFactory.setHostName(host);
        try {
            mqQueueConnectionFactory.setSSLCipherSuite(sslCipherSuite);
            mqQueueConnectionFactory.setSSLSocketFactory(sslSocketFactory);
            mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
            mqQueueConnectionFactory.setCCSID(1208);
            mqQueueConnectionFactory.setChannel(channel);
            mqQueueConnectionFactory.setPort(port);
            mqQueueConnectionFactory.setQueueManager(queueManager);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mqQueueConnectionFactory;
    }

    public UserCredentialsConnectionFactoryAdapter genUserCredentialsConnectionFactoryAdapter(MQQueueConnectionFactory mqQueueConnectionFactory) {
        UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter = new UserCredentialsConnectionFactoryAdapter();
        userCredentialsConnectionFactoryAdapter.setUsername(username);
        userCredentialsConnectionFactoryAdapter.setPassword(password);
        userCredentialsConnectionFactoryAdapter.setTargetConnectionFactory(mqQueueConnectionFactory);
        return userCredentialsConnectionFactoryAdapter;
    }

    public CachingConnectionFactory genCachingConnectionFactory(UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter) {
        CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory();
        cachingConnectionFactory.setTargetConnectionFactory(userCredentialsConnectionFactoryAdapter);
        cachingConnectionFactory.setSessionCacheSize(500);
        cachingConnectionFactory.setReconnectOnException(true);
        return cachingConnectionFactory;
    }

    public JmsListenerContainerFactory<?> genJmsListenerContainerFactory(MQQueueConnectionFactory mqQueueConnectionFactory, DefaultJmsListenerContainerFactoryConfigurer configurer){
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, mqQueueConnectionFactory);
        return factory;
    }

    public JmsTemplate genJmsTemplate(CachingConnectionFactory cachingConnectionFactory) {
        JmsTemplate jmsTemplate = new JmsTemplate(cachingConnectionFactory);
        jmsTemplate.setReceiveTimeout(receiveTimeout);
        return jmsTemplate;
    }

    public MessageCreator genMessageCreator(String replyToQ, RequestMessage message) {
        reqLs.put(message.getMsgId(), message.getMsgBody());

        // java 8
        return (Session session) -> {
            TextMessage txtMessage = session.createTextMessage(message.getMsgBody());
            txtMessage.setJMSReplyTo(session.createQueue(replyToQ));
            txtMessage.setJMSCorrelationID(message.getMsgId());
            SecurityUtil.logMessage("Message Headers => " + txtMessage.toString().replaceAll("[\r\n]+", ","));
            return txtMessage;
        };

//        return new MessageCreator() {
//            @Override
//            public Message createMessage(Session session) throws JMSException {
//                TextMessage txtMessage = session.createTextMessage(message);
//                SecurityUtil.logMessage("Message Headers => " + txtMessage.toString().replaceAll("[\r\n]+", ","));
//                return txtMessage;
//            }
//        };
    }

    public String genTimestamp(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        return sdf.format(new Date());
    }

    public void sendMessageQM1(String queueName, String message){
        String msgId = "REQ_MSG-"+genTimestamp();
        RequestMessage req = new RequestMessage(msgId, message);
        jmsOperations.send(queueName, genMessageCreator(queueName, req));
    }

    public void sendMessageQM2(String queueName, String message){
        String msgId = "REQ_MSG-"+genTimestamp();
        RequestMessage req = new RequestMessage(msgId, message);
        jmsOperations2.send(queueName, genMessageCreator(queueName, req));
    }

    public void listenMessage(String queueManager, String queueResponse){
        if(reqLs.size() < 1){
            return;
        }

        List<String> resLs = new ArrayList<String>();
        if("QM01".equals(queueManager)){
            resLs = browseAndSelectMessage(jmsOperations, queueResponse);
        }else if("QM02".equals(queueManager)){
            resLs = browseAndSelectMessage(jmsOperations2, queueResponse);
        }

        // do something with response message list here
        for (String str: resLs) {
            SecurityUtil.logMessage("Message - " + str);
        }
    }

    private List<String> browseAndSelectMessage(JmsOperations jmsOperation, String queueName){
        List<String> resLs = jmsOperation.browse(queueName, new BrowserCallback<List<String>>() {
            @Override
            public List<String> doInJms(Session session, QueueBrowser queueBrowser) throws JMSException {
                List<String> messContentList = new ArrayList<String>();
                final Enumeration<Message> messageEnum = queueBrowser.getEnumeration();
                while (messageEnum.hasMoreElements()){
                    final Message msg = messageEnum.nextElement();
                    if(reqLs.containsKey(msg.getJMSCorrelationID())){
                        final TextMessage tm = (TextMessage) jmsOperation.receiveSelected(queueName, "JMSCorrelationID = '" + msg.getJMSCorrelationID() + "'");
                        messContentList.add(tm.getText());
                    }
                }
                return messContentList;
            }
        });
        return resLs;
    }
}
